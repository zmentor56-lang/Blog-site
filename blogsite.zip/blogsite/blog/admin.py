from django.contrib import admin
from django.utils.html import format_html
from .models import Category, Tag, Post, Comment, NewsletterSubscriber


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display        = ['name', 'slug', 'color_preview', 'icon', 'post_count', 'created_at']
    prepopulated_fields = {'slug': ('name',)}
    search_fields       = ['name']

    def color_preview(self, obj):
        return format_html(
            '<span style="background:{};padding:3px 12px;'
            'border-radius:4px;color:white;font-size:12px;">{}</span>',
            obj.color, obj.color
        )
    color_preview.short_description = 'Color'

    def post_count(self, obj):
        return obj.get_post_count()
    post_count.short_description = 'Posts'


@admin.register(Tag)
class TagAdmin(admin.ModelAdmin):
    list_display        = ['name', 'slug']
    prepopulated_fields = {'slug': ('name',)}
    search_fields       = ['name']


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display        = ['title', 'author', 'category', 'status', 'is_featured', 'views', 'published_at']
    list_filter         = ['status', 'is_featured', 'category']
    list_editable       = ['status', 'is_featured']
    search_fields       = ['title', 'excerpt', 'body']
    prepopulated_fields = {'slug': ('title',)}
    filter_horizontal   = ['tags']
    readonly_fields     = ['views', 'created_at', 'updated_at']

    fieldsets = (
        ('Content', {
            'fields': ('title', 'slug', 'author', 'body', 'excerpt')
        }),
        ('Media', {
            'fields': ('featured_image',)
        }),
        ('Classification', {
            'fields': ('category', 'tags')
        }),
        ('Publishing', {
            'fields': ('status', 'is_featured', 'published_at')
        }),
        ('Stats', {
            'fields': ('views', 'created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

    def save_model(self, request, obj, form, change):
        if not obj.pk:
            obj.author = request.user
        super().save_model(request, obj, form, change)


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display  = ['name', 'email', 'post', 'is_approved', 'created_at']
    list_filter   = ['is_approved', 'created_at']
    list_editable = ['is_approved']
    search_fields = ['name', 'email', 'body']

    def approve_comments(self, request, queryset):
        queryset.update(is_approved=True)
    approve_comments.short_description = 'Approve selected comments'


@admin.register(NewsletterSubscriber)
class NewsletterSubscriberAdmin(admin.ModelAdmin):
    list_display = ['email', 'subscribed_at', 'is_active']
    list_filter  = ['is_active', 'subscribed_at']
    search_fields = ['email']