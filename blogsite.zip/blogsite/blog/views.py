from django.shortcuts import render, get_object_or_404, redirect
from django.views.generic import ListView, DetailView, TemplateView, FormView
from django.contrib import messages
from django.db.models import Q
from django.http import JsonResponse
from .models import Post, Category, Comment
from .forms import CommentForm, NewsletterForm, ContactForm


def get_common_context():
    return {
        'categories': Category.objects.all(),
        'popular_posts': Post.objects.filter(
            status='published'
        ).order_by('-views')[:5],
    }


class HomeView(TemplateView):
    template_name = 'blog/home.html'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx.update(get_common_context())
        ctx['featured_posts'] = Post.objects.filter(
            status='published',
            is_featured=True
        ).select_related('author', 'category')[:3]
        ctx['latest_posts'] = Post.objects.filter(
            status='published'
        ).select_related('author', 'category')[:9]
        return ctx


class PostDetailView(DetailView):
    model               = Post
    template_name       = 'blog/post_detail.html'
    context_object_name = 'post'

    def get_queryset(self):
        return Post.objects.filter(
            status='published'
        ).select_related('author', 'category')

    def get_object(self, queryset=None):
        obj = super().get_object(queryset)
        obj.increment_views()
        return obj

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx.update(get_common_context())
        ctx['comment_form']  = CommentForm()
        ctx['comments']      = self.object.comments.filter(is_approved=True)
        ctx['related_posts'] = self.object.get_related_posts(3)
        ctx['read_time']     = self.object.get_read_time()
        return ctx

    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        form = CommentForm(request.POST)
        if form.is_valid():
            comment      = form.save(commit=False)
            comment.post = self.object
            comment.save()
            messages.success(request, 'Comment submitted and awaiting approval.')
            return redirect('blog:post_detail', slug=self.object.slug)
        ctx = self.get_context_data()
        ctx['comment_form'] = form
        return render(request, self.template_name, ctx)


class CategoryView(ListView):
    template_name       = 'blog/category.html'
    context_object_name = 'posts'
    paginate_by         = 9

    def get_queryset(self):
        self.category = get_object_or_404(Category, slug=self.kwargs['slug'])
        return Post.objects.filter(
            status='published',
            category=self.category
        ).select_related('author', 'category')

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx.update(get_common_context())
        ctx['category'] = self.category
        return ctx


class SearchView(ListView):
    template_name       = 'blog/search_results.html'
    context_object_name = 'posts'
    paginate_by         = 9

    def get_queryset(self):
        query = self.request.GET.get('query', '')
        if query:
            return Post.objects.filter(
                status='published'
            ).filter(
                Q(title__icontains=query) |
                Q(excerpt__icontains=query) |
                Q(body__icontains=query)
            ).distinct().select_related('author', 'category')
        return Post.objects.none()

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx.update(get_common_context())
        ctx['query']        = self.request.GET.get('query', '')
        ctx['result_count'] = self.get_queryset().count()
        return ctx


class AboutView(TemplateView):
    template_name = 'blog/about.html'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx.update(get_common_context())
        return ctx


class ContactView(FormView):
    template_name = 'blog/contact.html'
    form_class    = ContactForm
    success_url   = '/contact/'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx.update(get_common_context())
        return ctx

    def form_valid(self, form):
        messages.success(
            self.request,
            'Thank you! We will get back to you within 24 hours.'
        )
        return super().form_valid(form)


def newsletter_subscribe(request):
    if request.method == 'POST':
        form = NewsletterForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                return JsonResponse({
                    'success': True,
                    'message': 'Successfully subscribed!'
                })
            except Exception:
                return JsonResponse({
                    'success': False,
                    'message': 'Email already subscribed.'
                })
        return JsonResponse({
            'success': False,
            'message': 'Enter a valid email.'
        })
    return JsonResponse({
        'success': False,
        'message': 'Invalid request.'
    })