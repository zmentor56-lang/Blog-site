from django import forms
from .models import Comment, NewsletterSubscriber


class CommentForm(forms.ModelForm):
    class Meta:
        model  = Comment
        fields = ['name', 'email', 'body']
        widgets = {
            'name':  forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Your full name'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'your@email.com'}),
            'body':  forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Share your thoughts...', 'rows': 4}),
        }


class NewsletterForm(forms.ModelForm):
    class Meta:
        model  = NewsletterSubscriber
        fields = ['email']
        widgets = {
            'email': forms.EmailInput(attrs={'class': 'newsletter-input', 'placeholder': 'Enter your email'}),
        }


class SearchForm(forms.Form):
    query = forms.CharField(
        max_length=200,
        widget=forms.TextInput(attrs={'class': 'search-input', 'placeholder': 'Search articles...', 'autocomplete': 'off'})
    )


class ContactForm(forms.Form):
    name    = forms.CharField(max_length=100, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Your full name'}))
    email   = forms.EmailField(widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'your@email.com'}))
    subject = forms.CharField(max_length=200, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Subject'}))
    message = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Your message...', 'rows': 5}))