from django.urls import path
from . import views

app_name = 'blog'

urlpatterns = [
    path('',                        views.HomeView.as_view(),         name='home'),
    path('post/<slug:slug>/',       views.PostDetailView.as_view(),   name='post_detail'),
    path('category/<slug:slug>/',   views.CategoryView.as_view(),     name='category'),
    path('search/',                 views.SearchView.as_view(),       name='search'),
    path('about/',                  views.AboutView.as_view(),        name='about'),
    path('contact/',                views.ContactView.as_view(),      name='contact'),
    path('newsletter/subscribe/',   views.newsletter_subscribe,       name='newsletter_subscribe'),
]