from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from django.utils.text import slugify
import math


class Category(models.Model):
    name        = models.CharField(max_length=100, unique=True)
    slug        = models.SlugField(max_length=100, unique=True, blank=True)
    description = models.TextField(blank=True)
    color       = models.CharField(max_length=7, default='#6C63FF')
    icon        = models.CharField(max_length=50, default='📝')
    created_at  = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = 'Categories'
        ordering = ['name']

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name

    def get_post_count(self):
        return self.posts.filter(status='published').count()


class Tag(models.Model):
    name = models.CharField(max_length=50, unique=True)
    slug = models.SlugField(max_length=50, unique=True, blank=True)

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name


class Post(models.Model):
    STATUS_CHOICES = [
        ('draft',     'Draft'),
        ('published', 'Published'),
    ]

    title          = models.CharField(max_length=250)
    slug           = models.SlugField(max_length=250, unique_for_date='published_at', blank=True)
    author         = models.ForeignKey(User, on_delete=models.CASCADE, related_name='blog_posts')
    category       = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, blank=True, related_name='posts')
    tags           = models.ManyToManyField(Tag, blank=True, related_name='posts')
    featured_image = models.ImageField(upload_to='posts/%Y/%m/', blank=True, null=True)
    excerpt        = models.TextField(max_length=500, blank=True)
    body           = models.TextField()
    status         = models.CharField(max_length=10, choices=STATUS_CHOICES, default='draft')
    is_featured    = models.BooleanField(default=False)
    views          = models.PositiveIntegerField(default=0)
    published_at   = models.DateTimeField(null=True, blank=True)
    created_at     = models.DateTimeField(auto_now_add=True)
    updated_at     = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-published_at']

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title)
        if self.status == 'published' and not self.published_at:
            self.published_at = timezone.now()
        super().save(*args, **kwargs)

    def __str__(self):
        return self.title

    def get_read_time(self):
        import re
        from django.conf import settings
        clean = re.sub(r'<[^>]+>', '', str(self.body))
        words = len(clean.split())
        mins  = math.ceil(words / getattr(settings, 'WORDS_PER_MINUTE', 200))
        return max(1, mins)

    def increment_views(self):
        self.views += 1
        self.save(update_fields=['views'])

    def get_related_posts(self, count=3):
        qs = Post.objects.filter(status='published').exclude(id=self.id)
        if self.category:
            cat_qs = qs.filter(category=self.category)[:count]
            if cat_qs.count() >= count:
                return cat_qs
        return qs[:count]


class Comment(models.Model):
    post       = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='comments')
    name       = models.CharField(max_length=100)
    email      = models.EmailField()
    body       = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    is_approved = models.BooleanField(default=False)

    class Meta:
        ordering = ['created_at']

    def __str__(self):
        return f'Comment by {self.name} on {self.post}'


class NewsletterSubscriber(models.Model):
    email         = models.EmailField(unique=True)
    subscribed_at = models.DateTimeField(auto_now_add=True)
    is_active     = models.BooleanField(default=True)

    def __str__(self):
        return self.email